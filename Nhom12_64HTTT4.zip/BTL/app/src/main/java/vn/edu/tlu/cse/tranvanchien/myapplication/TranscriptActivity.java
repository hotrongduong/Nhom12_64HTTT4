package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.HashMap;

public class TranscriptActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private String studentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transcript);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        dbHelper = new DatabaseHelper(this);
        studentId = getIntent().getStringExtra("STUDENT_ID");

        TextView tvSecurity = findViewById(R.id.tvSecurity);
        TextView tvAndroid = findViewById(R.id.tvAndroid);
        TextView tvSoftComputing = findViewById(R.id.tvSoftComputing);
        TextView tvAverage = findViewById(R.id.tvAverage);

        HashMap<String, Float> grades = dbHelper.getStudentGrades(studentId);
        tvSecurity.setText("An toàn và bảo mật thông tin: " + grades.get("An toàn và bảo mật thông tin"));
        tvAndroid.setText("Lập trình Android: " + grades.get("Lập trình Android"));
        tvSoftComputing.setText("Tính toán mềm: " + grades.get("Tính toán mềm"));

        float average = (grades.get("An toàn và bảo mật thông tin") + grades.get("Lập trình Android") + grades.get("Tính toán mềm")) / 3;
        tvAverage.setText("Điểm trung bình: " + String.format("%.2f", average));
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}