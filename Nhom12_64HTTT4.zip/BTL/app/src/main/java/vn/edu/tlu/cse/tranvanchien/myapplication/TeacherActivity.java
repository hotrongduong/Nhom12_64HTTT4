package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;

public class TeacherActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_CONDUCT = 1;
    private static final int REQUEST_CODE_TRAINING_POINTS = 2;

    private ListView lvStudents;
    private Button btnAddStudent, btnLogout;
    private DatabaseHelper dbHelper;
    private ArrayList<HashMap<String, String>> studentList;
    private ArrayAdapter<String> adapter;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lvStudents = findViewById(R.id.lvStudents);
        btnAddStudent = findViewById(R.id.btnAddStudent);
        btnLogout = findViewById(R.id.btnLogout);
        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        loadStudents();

        btnAddStudent.setOnClickListener(v -> showStudentDialog(null));

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(this, LoginActivity.class); // Hoặc LoginActivity.class nếu bạn dùng LoginActivity
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        lvStudents.setOnItemClickListener((parent, view, position, id) -> {
            HashMap<String, String> student = studentList.get(position);
            showStudentDialog(student);
        });

        lvStudents.setOnItemLongClickListener((parent, view, position, id) -> {
            HashMap<String, String> student = studentList.get(position);
            new AlertDialog.Builder(this)
                    .setTitle("Xóa sinh viên")
                    .setMessage("Bạn có chắc muốn xóa " + student.get("fullname") + "?")
                    .setPositiveButton("Có", (dialog, which) -> {
                        dbHelper.deleteStudent(student.get("student_id"));
                        loadStudents();
                    })
                    .setNegativeButton("Không", null)
                    .show();
            return true;
        });
    }

    private void loadStudents() {
        studentList = dbHelper.getAllStudents();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2,
                android.R.id.text1,
                studentList.stream().map(s -> s.get("fullname") + "\nHọc lực: " + s.get("average") +
                        " | Hạnh kiểm: " + s.get("conduct") + " | Điểm RL: " + s.get("training_points")).collect(Collectors.toList()));
        lvStudents.setAdapter(adapter);
    }

    public void refreshStudentList() {
        studentList = dbHelper.getAllStudents();
        adapter.clear();
        adapter.addAll(studentList.stream().map(s -> s.get("fullname") + "\nHọc lực: " + s.get("average") +
                " | Hạnh kiểm: " + s.get("conduct") + " | Điểm RL: " + s.get("training_points")).collect(Collectors.toList()));
        adapter.notifyDataSetChanged();
    }

    private void showStudentDialog(HashMap<String, String> student) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_student, null);
        builder.setView(dialogView);

        EditText etStudentId = dialogView.findViewById(R.id.etStudentId);
        EditText etFullName = dialogView.findViewById(R.id.etFullName);
        EditText etClass = dialogView.findViewById(R.id.etClass);
        Spinner spGender = dialogView.findViewById(R.id.spGender);
        EditText etSecurityGrade = dialogView.findViewById(R.id.etSecurityGrade);
        EditText etAndroidGrade = dialogView.findViewById(R.id.etAndroidGrade);
        EditText etSoftComputingGrade = dialogView.findViewById(R.id.etSoftComputingGrade);

        ArrayAdapter<String> genderAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, new String[]{"Nam", "Nữ"});
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGender.setAdapter(genderAdapter);

        boolean isEdit = student != null;
        if (isEdit) {
            etStudentId.setText(student.get("student_id"));
            etStudentId.setEnabled(false);
            etFullName.setText(student.get("fullname"));
            etClass.setText(student.get("class"));
            spGender.setSelection(student.get("gender").equals("Nam") ? 0 : 1);
            HashMap<String, Float> grades = dbHelper.getStudentGrades(student.get("student_id"));
            etSecurityGrade.setText(String.valueOf(grades.get("An toàn và bảo mật thông tin")));
            etAndroidGrade.setText(String.valueOf(grades.get("Lập trình Android")));
            etSoftComputingGrade.setText(String.valueOf(grades.get("Tính toán mềm")));
            builder.setTitle("Sửa thông tin sinh viên");
        } else {
            builder.setTitle("Thêm sinh viên mới");
        }

        builder.setPositiveButton(isEdit ? "Lưu" : "Thêm", null);
        builder.setNegativeButton("Hủy", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String studentId = etStudentId.getText().toString().trim();
            String fullname = etFullName.getText().toString().trim();
            String className = etClass.getText().toString().trim();
            String gender = spGender.getSelectedItem().toString();
            float securityGrade, androidGrade, softComputingGrade;

            try {
                securityGrade = Float.parseFloat(etSecurityGrade.getText().toString().trim());
                androidGrade = Float.parseFloat(etAndroidGrade.getText().toString().trim());
                softComputingGrade = Float.parseFloat(etSoftComputingGrade.getText().toString().trim());
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Vui lòng nhập điểm hợp lệ", Toast.LENGTH_SHORT).show();
                return;
            }

            if (studentId.isEmpty() || fullname.isEmpty() || className.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                if (isEdit) {
                    dbHelper.updateStudent(studentId, fullname, className, gender,
                            securityGrade, androidGrade, softComputingGrade);
                } else {
                    dbHelper.addStudent(studentId, fullname, className, gender,
                            securityGrade, androidGrade, softComputingGrade);
                }
                loadStudents();
                dialog.dismiss();
            } catch (SQLiteConstraintException e) {
                Toast.makeText(this, "Mã sinh viên " + studentId + " đã tồn tại", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.teacher_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_conduct) {
            Intent intent = new Intent(this, ConductActivity.class);
            startActivityForResult(intent, REQUEST_CODE_CONDUCT);
            return true;
        } else if (id == R.id.menu_training_points) {
            Intent intent = new Intent(this, TrainingPointsActivity.class);
            startActivityForResult(intent, REQUEST_CODE_TRAINING_POINTS);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && (requestCode == REQUEST_CODE_CONDUCT || requestCode == REQUEST_CODE_TRAINING_POINTS)) {
            refreshStudentList();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}