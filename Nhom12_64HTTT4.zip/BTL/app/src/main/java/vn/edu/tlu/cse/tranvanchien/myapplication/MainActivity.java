package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;
    private Spinner spRole;
    private Button btnLogin;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        spRole = findViewById(R.id.spRole);
        btnLogin = findViewById(R.id.btnLogin);
        dbHelper = new DatabaseHelper(this);

        // Thiết lập Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Sinh viên", "Giảng viên"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spRole.setAdapter(adapter);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                // Chuyển đổi vai trò từ Spinner thành giá trị trong cơ sở dữ liệu
                String selectedRole = spRole.getSelectedItemPosition() == 0 ? "Sinh viên" : "Giảng viên";

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "Vui lòng nhập đầy đủ thông tin",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                // Kiểm tra thông tin đăng nhập với vai trò
                if (dbHelper.checkUser(username, password, selectedRole)) {
                    Intent intent;
                    if (selectedRole.equals("Sinh viên")) {
                        intent = new Intent(MainActivity.this, StudentActivity.class);
                    } else {
                        intent = new Intent(MainActivity.this, TeacherActivity.class);
                    }
                    intent.putExtra("username", username);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this,
                            "Thông tin đăng nhập không đúng hoặc vai trò không khớp",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}