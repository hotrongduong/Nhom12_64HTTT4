package vn.edu.tlu.cse.tranvanchien.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "StudentManagement.db";
    private static final int DATABASE_VERSION = 10; // Tăng version do thêm bảng mới

    private static final String TABLE_USERS = "users";
    private static final String TABLE_STUDENT_INFO = "student_info";
    private static final String TABLE_GRADES = "grades";
    private static final String TABLE_CONDUCT = "conduct";
    private static final String TABLE_TRAINING_POINTS = "training_points";
    private static final String TABLE_SCHEDULE = "schedule";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE users (" +
                "COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "COLUMN_USERNAME TEXT, " +
                "COLUMN_PASSWORD TEXT, " +
                "COLUMN_ROLE TEXT)");

        db.execSQL("CREATE TABLE student_info (" +
                "COLUMN_STUDENT_ID TEXT PRIMARY KEY, " +
                "COLUMN_FULLNAME TEXT, " +
                "COLUMN_CLASS TEXT, " +
                "COLUMN_GENDER TEXT)");

        db.execSQL("CREATE TABLE grades (" +
                "COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "COLUMN_STUDENT_ID TEXT REFERENCES student_info(COLUMN_STUDENT_ID), " +
                "COLUMN_SUBJECT TEXT, " +
                "COLUMN_GRADE REAL)");

        db.execSQL("CREATE TABLE conduct (" +
                "COLUMN_STUDENT_ID TEXT PRIMARY KEY REFERENCES student_info(COLUMN_STUDENT_ID), " +
                "COLUMN_CONDUCT TEXT)");

        db.execSQL("CREATE TABLE training_points (" +
                "COLUMN_STUDENT_ID TEXT PRIMARY KEY REFERENCES student_info(COLUMN_STUDENT_ID), " +
                "COLUMN_TRAINING_POINTS REAL)");

        db.execSQL("CREATE TABLE schedule (" +
                "COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "COLUMN_STUDENT_ID TEXT REFERENCES student_info(COLUMN_STUDENT_ID), " +
                "COLUMN_SUBJECT TEXT, " +
                "COLUMN_TIME TEXT, " +
                "COLUMN_ROOM TEXT)");

        // Dữ liệu mẫu
        // Tài khoản giảng viên
        db.execSQL("INSERT INTO users (COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_ROLE) VALUES ('teacher1', '123456', 'Giảng viên')");

        // 3 tài khoản sinh viên
        db.execSQL("INSERT INTO users (COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_ROLE) VALUES ('SV001', '123456', 'Sinh viên')");
        db.execSQL("INSERT INTO users (COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_ROLE) VALUES ('SV002', '123456', 'Sinh viên')");
        db.execSQL("INSERT INTO users (COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_ROLE) VALUES ('SV003', '123456', 'Sinh viên')");

        // Thông tin 3 sinh viên
        db.execSQL("INSERT INTO student_info (COLUMN_STUDENT_ID, COLUMN_FULLNAME, COLUMN_CLASS, COLUMN_GENDER) " +
                "VALUES ('SV001', 'Trần Văn Chiến', '64HTTT4', 'Nam')");
        db.execSQL("INSERT INTO student_info (COLUMN_STUDENT_ID, COLUMN_FULLNAME, COLUMN_CLASS, COLUMN_GENDER) " +
                "VALUES ('SV002', 'Hồ Trọng Dương', '64HTTT4', 'Nam')");
        db.execSQL("INSERT INTO student_info (COLUMN_STUDENT_ID, COLUMN_FULLNAME, COLUMN_CLASS, COLUMN_GENDER) " +
                "VALUES ('SV003', 'Trần Thị Hoài', '64HTTT4', 'Nữ')");

        // Điểm số mẫu
        String[] subjects = {"An toàn và bảo mật thông tin", "Lập trình Android", "Tính toán mềm"};
        String[] studentIds = {"SV001", "SV002", "SV003"};
        float[][] grades = {
                {8.5f, 7.8f, 9.0f}, // SV001
                {7.0f, 6.5f, 8.0f}, // SV002
                {8.0f, 8.5f, 7.5f}  // SV003
        };
        for (int i = 0; i < studentIds.length; i++) {
            for (int j = 0; j < subjects.length; j++) {
                db.execSQL("INSERT INTO " + TABLE_GRADES + " (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_GRADE) " +
                        "VALUES ('" + studentIds[i] + "', '" + subjects[j] + "', " + grades[i][j] + ")");
            }
        }

        // Hạnh kiểm mẫu
        db.execSQL("INSERT INTO conduct (COLUMN_STUDENT_ID, COLUMN_CONDUCT) VALUES ('SV001', 'Tốt')");
        db.execSQL("INSERT INTO conduct (COLUMN_STUDENT_ID, COLUMN_CONDUCT) VALUES ('SV002', 'Khá')");

        // Điểm rèn luyện mẫu
        db.execSQL("INSERT INTO training_points (COLUMN_STUDENT_ID, COLUMN_TRAINING_POINTS) VALUES ('SV001', 85.0)");
        db.execSQL("INSERT INTO training_points (COLUMN_STUDENT_ID, COLUMN_TRAINING_POINTS) VALUES ('SV003', 90.0)");

        // Lịch học mẫu
        db.execSQL("INSERT INTO schedule (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM) " +
                "VALUES ('SV001', 'Khai Phá Dữ Liệu', 'Thứ 2, 7:30-9:30', 'P101')");
        db.execSQL("INSERT INTO schedule (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM) " +
                "VALUES ('SV001', 'Nhập Môn Điện toán Đám mây', 'Thứ 3, 9:45-11:45', 'P102')");
        db.execSQL("INSERT INTO schedule (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM) " +
                "VALUES ('SV001', 'Lập Trình Python', 'Thứ 4, 13:30-15:30', 'P103')");
        db.execSQL("INSERT INTO schedule (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM) " +
                "VALUES ('SV002', 'Bóng Chuyền 1', 'Thứ 2, 7:30-9:30', 'Sân Bóng Chuyền 1')");
        db.execSQL("INSERT INTO schedule (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM) " +
                "VALUES ('SV002', 'Lập Trình Hướng Đối Tượng', 'Thứ 3, 9:45-11:45', 'P108')");
        db.execSQL("INSERT INTO schedule (COLUMN_STUDENT_ID, COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM) " +
                "VALUES ('SV003', 'Tư Tưởng HCM', 'Thứ 4, 13:30-15:30', 'P106')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENT_INFO);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GRADES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CONDUCT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRAINING_POINTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEDULE);
        onCreate(db);
    }

    public boolean checkUser(String username, String password, String role) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE COLUMN_USERNAME = ? AND COLUMN_PASSWORD = ? AND COLUMN_ROLE = ?",
                new String[]{username, password, role});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    public ArrayList<HashMap<String, String>> getAllStudents() {
        ArrayList<HashMap<String, String>> studentList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT si.COLUMN_STUDENT_ID, si.COLUMN_FULLNAME, si.COLUMN_CLASS, si.COLUMN_GENDER, " +
                "c.COLUMN_CONDUCT, tp.COLUMN_TRAINING_POINTS " +
                "FROM student_info si " +
                "LEFT JOIN conduct c ON si.COLUMN_STUDENT_ID = c.COLUMN_STUDENT_ID " +
                "LEFT JOIN training_points tp ON si.COLUMN_STUDENT_ID = tp.COLUMN_STUDENT_ID", null);
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> student = new HashMap<>();
                student.put("student_id", cursor.getString(0));
                student.put("fullname", cursor.getString(1));
                student.put("class", cursor.getString(2));
                student.put("gender", cursor.getString(3));
                student.put("conduct", cursor.isNull(4) ? "null" : cursor.getString(4));
                student.put("training_points", cursor.isNull(5) ? "null" : cursor.getString(5));

                Cursor gradeCursor = db.rawQuery("SELECT AVG(COLUMN_GRADE) FROM grades WHERE COLUMN_STUDENT_ID = ?",
                        new String[]{cursor.getString(0)});
                if (gradeCursor.moveToFirst()) {
                    student.put("average", String.format("%.2f", gradeCursor.getFloat(0)));
                }
                gradeCursor.close();
                studentList.add(student);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return studentList;
    }

    public void addStudent(String studentId, String fullName, String className, String gender,
                           float securityGrade, float androidGrade, float softComputingGrade) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues studentValues = new ContentValues();
            studentValues.put("COLUMN_STUDENT_ID", studentId);
            studentValues.put("COLUMN_FULLNAME", fullName);
            studentValues.put("COLUMN_CLASS", className);
            studentValues.put("COLUMN_GENDER", gender);
            db.insertOrThrow(TABLE_STUDENT_INFO, null, studentValues);

            ContentValues userValues = new ContentValues();
            userValues.put("COLUMN_USERNAME", studentId);
            userValues.put("COLUMN_PASSWORD", "123456");
            userValues.put("COLUMN_ROLE", "Sinh viên");
            db.insertOrThrow(TABLE_USERS, null, userValues);

            String[] subjects = {"An toàn và bảo mật thông tin", "Lập trình Android", "Tính toán mềm"};
            float[] grades = {securityGrade, androidGrade, softComputingGrade};
            for (int i = 0; i < subjects.length; i++) {
                ContentValues gradeValues = new ContentValues();
                gradeValues.put("COLUMN_STUDENT_ID", studentId);
                gradeValues.put("COLUMN_SUBJECT", subjects[i]);
                gradeValues.put("COLUMN_GRADE", grades[i]);
                db.insert(TABLE_GRADES, null, gradeValues);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void updateStudent(String studentId, String fullName, String className, String gender,
                              float securityGrade, float androidGrade, float softComputingGrade) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues studentValues = new ContentValues();
            studentValues.put("COLUMN_FULLNAME", fullName);
            studentValues.put("COLUMN_CLASS", className);
            studentValues.put("COLUMN_GENDER", gender);
            db.update(TABLE_STUDENT_INFO, studentValues, "COLUMN_STUDENT_ID = ?", new String[]{studentId});

            String[] subjects = {"An toàn và bảo mật thông tin", "Lập trình Android", "Tính toán mềm"};
            float[] grades = {securityGrade, androidGrade, softComputingGrade};
            for (int i = 0; i < subjects.length; i++) {
                ContentValues gradeValues = new ContentValues();
                gradeValues.put("COLUMN_GRADE", grades[i]);
                db.update(TABLE_GRADES, gradeValues,
                        "COLUMN_STUDENT_ID = ? AND COLUMN_SUBJECT = ?", new String[]{studentId, subjects[i]});
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public void deleteStudent(String studentId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete(TABLE_USERS, "COLUMN_USERNAME = ?", new String[]{studentId});
            db.delete(TABLE_GRADES, "COLUMN_STUDENT_ID = ?", new String[]{studentId});
            db.delete(TABLE_CONDUCT, "COLUMN_STUDENT_ID = ?", new String[]{studentId});
            db.delete(TABLE_TRAINING_POINTS, "COLUMN_STUDENT_ID = ?", new String[]{studentId});
            db.delete(TABLE_STUDENT_INFO, "COLUMN_STUDENT_ID = ?", new String[]{studentId});
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public HashMap<String, String> getStudentInfo(String studentId) {
        HashMap<String, String> studentInfo = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT si.COLUMN_STUDENT_ID, si.COLUMN_FULLNAME, si.COLUMN_CLASS, si.COLUMN_GENDER, " +
                "c.COLUMN_CONDUCT, tp.COLUMN_TRAINING_POINTS, AVG(g.COLUMN_GRADE) as average_grade " +
                "FROM student_info si " +
                "LEFT JOIN conduct c ON si.COLUMN_STUDENT_ID = c.COLUMN_STUDENT_ID " +
                "LEFT JOIN training_points tp ON si.COLUMN_STUDENT_ID = tp.COLUMN_STUDENT_ID " +
                "LEFT JOIN grades g ON si.COLUMN_STUDENT_ID = g.COLUMN_STUDENT_ID " +
                "WHERE si.COLUMN_STUDENT_ID = ? " +
                "GROUP BY si.COLUMN_STUDENT_ID, si.COLUMN_FULLNAME, si.COLUMN_CLASS, si.COLUMN_GENDER, " +
                "c.COLUMN_CONDUCT, tp.COLUMN_TRAINING_POINTS", new String[]{studentId});
        if (cursor.moveToFirst()) {
            studentInfo.put("student_id", cursor.getString(0));
            studentInfo.put("fullname", cursor.getString(1));
            studentInfo.put("class", cursor.getString(2));
            studentInfo.put("gender", cursor.getString(3));
            studentInfo.put("conduct", cursor.isNull(4) ? "null" : cursor.getString(4));
            studentInfo.put("training_points", cursor.isNull(5) ? "null" : cursor.getString(5));
            studentInfo.put("average", cursor.isNull(6) ? "null" : String.format("%.2f", cursor.getFloat(6)));
        }
        cursor.close();
        return studentInfo;
    }

    public HashMap<String, Float> getStudentGrades(String studentId) {
        HashMap<String, Float> grades = new HashMap<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COLUMN_SUBJECT, COLUMN_GRADE FROM grades WHERE COLUMN_STUDENT_ID = ?", new String[]{studentId});
        if (cursor.moveToFirst()) {
            do {
                grades.put(cursor.getString(0), cursor.getFloat(1));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return grades;
    }

    public void updateConduct(String studentId, String conduct) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("COLUMN_CONDUCT", conduct);
        int rows = db.update(TABLE_CONDUCT, values, "COLUMN_STUDENT_ID = ?", new String[]{studentId});
        if (rows == 0) {
            values.put("COLUMN_STUDENT_ID", studentId);
            db.insert(TABLE_CONDUCT, null, values);
        }
    }

    public void updateTrainingPoints(String studentId, float points) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("COLUMN_TRAINING_POINTS", points);
        int rows = db.update(TABLE_TRAINING_POINTS, values, "COLUMN_STUDENT_ID = ?", new String[]{studentId});
        if (rows == 0) {
            values.put("COLUMN_STUDENT_ID", studentId);
            db.insert(TABLE_TRAINING_POINTS, null, values);
        }
    }

    public ArrayList<HashMap<String, String>> getStudentSchedule(String studentId) {
        ArrayList<HashMap<String, String>> scheduleList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COLUMN_SUBJECT, COLUMN_TIME, COLUMN_ROOM FROM schedule WHERE COLUMN_STUDENT_ID = ?",
                new String[]{studentId});
        if (cursor.moveToFirst()) {
            do {
                HashMap<String, String> schedule = new HashMap<>();
                schedule.put("subject", cursor.getString(0));
                schedule.put("time", cursor.getString(1));
                schedule.put("room", cursor.getString(2));
                scheduleList.add(schedule);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return scheduleList;
    }
}